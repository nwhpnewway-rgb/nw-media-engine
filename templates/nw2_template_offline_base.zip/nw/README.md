# Bộ Template Video Dọc 9:16 — NEWWAY Logistics JSC (24 Video · 192 Slide)

Bộ mẫu video chuyển động dọc chuẩn **TikTok / YouTube Shorts / Facebook Reels (`1080×1920`, tỷ lệ 9:16)** được thiết kế chuyên biệt cho thương hiệu **NEWWAY Logistics JSC** (`newwaylogisticsjsc`) trong lĩnh vực vận tải đa phương thức **Phân bón, Thức ăn chăn nuôi (TACN) và Hóa chất – Khí hóa lỏng (`CO₂`)**.

---

## 1. Cấu trúc gói đóng gói (`newway-logistics-video-template.zip`)

```text
newway-logistics-video-template/
├── animation.html                   # Bản nguồn tiêu chuẩn (kết nối thư mục assets/, đầy đủ công cụ biên tập & xuất bản)
├── newway-template-standalone.html  # Bản chạy độc lập 1 tệp duy nhất (đã nhúng sẵn cả 3 logo vào mã nguồn)
├── template-data.json               # Dữ liệu kịch bản chuẩn của 24 Video (192 Slide + 192 câu phụ đề Karaoke)
├── README.md                        # Tài liệu hướng dẫn sử dụng & biên tập nhanh
└── assets/                          # Thư mục tài nguyên thương hiệu gốc (không đóng khung)
    ├── logo-dark.png                # Logo dành cho nền tối (mặc định, tỷ lệ 400×96)
    ├── logo-full.png                # Logo đầy đủ màu (tỷ lệ 1840×462)
    └── logo-short.png               # Logo biểu tượng rút gọn vuông (tỷ lệ 462×462)
```

---

## 2. Danh mục 24 Video (192 Slide · 576 giây) tích hợp sẵn

Mỗi video gồm **8 slide mạch lạc** (thời lượng 3 giây/slide = **24 giây/video**) kèm **phụ đề Karaoke** tô sáng từng từ ở đáy khung hình:

1. **Nhóm Năng lực & Dịch vụ NEWWAY (`V01 – V12` · Slides `01 – 96`):**
   - `V01`: Giải pháp Logistics Đa Phương Thức Toàn Diện
   - `V02`: Chuỗi Cung Ứng & Vận Tải Phân Bón (Ure, DAP, NPK, Kali)
   - `V03`: Logistics Thức Ăn Chăn Nuôi (TACN) & Nguyên Liệu Nông Sản
   - `V04`: Vận Chuyển Hóa Chất & Khí Hóa Lỏng `CO₂` Chuyên Dụng
   - `V05`: Năng Lực Đội Xe Đường Bộ Chủ Lực
   - `V06`: Đường Thủy Nội Địa, Sà Lan & Kết Nối Cảng Biển
   - `V07`: Hệ Thống Kho Bãi & Khai Thác Hàng Rời
   - `V08`: Dịch Vụ Hải Quan & Thông Quan Chuyên Ngành
   - `V09`: Quản Trị An Toàn HSSE & Giám Sát Bồn `CO₂`
   - `V10`: Mô Hình Liên Vận Tàu Biển – Sà Lan – Đầu Kéo Door-to-Door
   - `V11`: Điều Phối Vận Hành & Theo Dõi Lô Hàng Thời Gian Thực
   - `V12`: Đối Tác Chuỗi Cung Ứng Nông Nghiệp & Công Nghiệp Bền Vững
2. **Nhóm Bài giảng Kiến thức Nghiệp vụ (`V13 – V15` · Slides `97 – 120`):**
   - `V13`: Bài giảng Container 20 Feet (`20'DC`) từ A–Z
   - `V14`: Bài giảng Container 40 Feet (`40'HC`) & Bồn ISO Tank Khí `CO₂`
   - `V15`: Bài giảng Hàng Rời (Bulk), Sang Mạn Sà Lan & Phí Cảng (`DEM/DET`, `THC`)
3. **Nhóm Lịch sử Hình thành & Phát triển (`V16 – V18` · Slides `121 – 144`):**
   - `V16`: Hành trình Hình thành & Phát triển NEWWAY Logistics JSC
   - `V17`: Lịch sử Container hóa & Vận tải Đa phương thức Thế giới
   - `V18`: Sự phát triển Chuỗi cung ứng Phân bón, TACN & Hóa chất tại Việt Nam
4. **Nhóm Bản tin Phân bón & Thị trường (`V19 – V21` · Slides `145 – 168`):**
   - `V19`: Bản tin Thị trường Phân bón & Kế hoạch Tập kết Mùa vụ
   - `V20`: Bản tin Khai thác Cầu Cảng Hàng Rời & Luồng Sà Lan Nội Địa
   - `V21`: Bản tin Bảo quản Chống ẩm Phân bón & TACN Mùa mưa ẩm
5. **Nhóm Văn bản Pháp luật & Quy định mới (`V22 – V24` · Slides `169 – 192`):**
   - `V22`: Pháp luật Nhập khẩu, Lưu hành & Kiểm dịch Phân bón – TACN
   - `V23`: Nghị định `34/2024/NĐ-CP` về Hàng nguy hiểm, Hóa chất & Bồn `CO₂`
   - `V24`: Luật Trật tự ATGT Đường bộ 2024, Tải trọng trục & Hải quan số hóa

---

## 3. Hướng dẫn sử dụng & sản xuất bài đăng mới nhanh chóng

### Cách 1: Gửi nhanh hoặc mở trên mọi máy tính không cần giải nén thư mục ảnh
- Mở trực tiếp tệp **`newway-template-standalone.html`** bằng trình duyệt Chrome, Edge hoặc Safari. Toàn bộ 3 phiên bản logo đã được nhúng sẵn bên trong tệp và có cơ chế chạy dòng thời gian dự phòng ngay cả khi máy tính ngoại tuyến.

### Cách 2: Chỉnh sửa trực tiếp trên màn hình & Lưu lại
1. Mở `animation.html` (hoặc `newway-template-standalone.html`).
2. Bấm nút **`Sửa chữ`** ở góc trên bảng điều khiển bên trái.
3. Nhấp chuột trực tiếp vào bất kỳ tiêu đề, con số, bảng thông số hoặc dòng CTA nào trên khung hình để gõ nội dung mới.
4. Trong mục **Lưu & Xuất bản Template** trên bảng điều khiển bên trái:
   - Bấm **`Lưu HTML đã sửa`** để tải về tệp `.html` mới giữ nguyên toàn bộ nội dung vừa biên tập.
   - Bấm **`Xuất Video Vxx (8S)`** để tách riêng kịch bản video đang mở thành **1 tệp HTML độc lập dài 24 giây (8 Slide)** dùng để quay hoặc xuất lẻ từng bài đăng TikTok/Shorts/Reels.

### Cách 3: Cập nhật hàng loạt bằng tệp kịch bản `template-data.json`
1. Mở tệp `template-data.json` bằng bất kỳ trình soạn thảo văn bản nào (hoặc bấm **`Xuất JSON kịch bản`** từ giao diện).
2. Chỉnh sửa câu văn tại trường `"karaokeSubtitle"` (hệ thống sẽ tự động tách từng từ để chạy hiệu ứng Karaoke) và mảng `"editableFields"` của video cần làm mới (ví dụ cập nhật kỳ mới cho `V19: Bản tin Thị trường Phân bón` hoặc `V22–V24: Điểm tin Pháp luật`).
3. Trên bảng điều khiển bên trái, bấm **`Nhập JSON kịch bản`** và chọn tệp `.json` vừa lưu — toàn bộ chữ trên slide và phụ đề Karaoke sẽ cập nhật tức thì.

---

## 4. Quy chuẩn thương hiệu đã khóa trong Template
- **Quy tắc 1 loại Logo duy nhất (Không đóng khung):** Tại mọi thời điểm chỉ hiển thị duy nhất 1 phiên bản logo (`Logo Nền Tối`, `Logo Đầy Đủ` hoặc `Logo Tắt`) trên toàn bộ khung hình, hoàn toàn trong suốt không viền/khung nền.
- **Không chồng chéo Logo & Handle:** Cụm logo đặt bên trái, tách biệt hoàn toàn với handle `newwaylogisticsjsc` bên phải; toàn bộ nội dung slide và thanh phụ đề Karaoke nằm gọn trong vùng an toàn chuẩn video dọc `1080×1920`.
- **Thay thế tệp ảnh Logo:** Khi cần cập nhật tệp ảnh logo mới (ví dụ bản gốc `logo-short.png`), chỉ cần chép đè tệp `.png` cùng tên vào thư mục `assets/` khi dùng cùng `animation.html`.
